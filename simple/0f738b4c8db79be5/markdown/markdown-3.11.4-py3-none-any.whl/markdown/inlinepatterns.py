# Python Markdown

# A Python implementation of John Gruber's Markdown.

# Documentation: https://python-markdown.github.io/
# GitHub: https://github.com/Python-Markdown/markdown/
# PyPI: https://pypi.org/project/Markdown/

# Started by Manfred Stienstra (http://www.dwerg.net/).
# Maintained for a few years by Yuri Takhteyev (http://www.freewisdom.org).
# Currently maintained by Waylan Limberg (https://github.com/waylan),
# Dmitry Shachnev (https://github.com/mitya57) and Isaac Muse (https://github.com/facelessuser).

# Copyright 2007-2023 The Python Markdown Project (v. 1.7 and later)
# Copyright 2004, 2005, 2006 Yuri Takhteyev (v. 0.2-1.6b)
# Copyright 2004 Manfred Stienstra (the original version)

# License: BSD (see LICENSE.md for details).

"""
In version 3.0, a new, more flexible inline processor was added, [`markdown.inlinepatterns.InlineProcessor`][].   The
original inline patterns, which inherit from [`markdown.inlinepatterns.Pattern`][] or one of its children are still
supported, though users are encouraged to migrate.

The new `InlineProcessor` provides two major enhancements to `Patterns`:

1. Inline Processors no longer need to match the entire block, so regular expressions no longer need to start with
  `r'^(.*?)'` and end with `r'(.*?)%'`. This runs faster. The returned [`Match`][re.Match] object will only contain
   what is explicitly matched in the pattern, and extension pattern groups now start with `m.group(1)`.

2.  The `handleMatch` method now takes an additional input called `data`, which is the entire block under analysis,
    not just what is matched with the specified pattern. The method now returns the element *and* the indexes relative
    to `data` that the return element is replacing (usually `m.start(0)` and `m.end(0)`).  If the boundaries are
    returned as `None`, it is assumed that the match did not take place, and nothing will be altered in `data`.

    This allows handling of more complex constructs than regular expressions can handle, e.g., matching nested
    brackets, and explicit control of the span "consumed" by the processor.

"""

from __future__ import annotations

from . import util
from typing import TYPE_CHECKING, Any, Collection, NamedTuple, cast
from collections import deque
import re
import xml.etree.ElementTree as etree
from html import entities
from bisect import bisect_left

if TYPE_CHECKING:  # pragma: no cover
    from markdown import Markdown


def build_inlinepatterns(md: Markdown, **kwargs: Any) -> util.Registry[InlineProcessor]:
    """
    Build the default set of inline patterns for Markdown.

    The order in which processors and/or patterns are applied is very important - e.g. if we first replace
    `http://.../` links with `<a>` tags and _then_ try to replace inline HTML, we would end up with a mess. So, we
    apply the expressions in the following order:

    * backticks and escaped characters have to be handled before everything else so that we can preempt any markdown
      patterns by escaping them;

    * then we handle the various types of links (auto-links must be handled before inline HTML);

    * then we handle inline HTML.  At this point we will simply replace all inline HTML strings with a placeholder
      and add the actual HTML to a stash;

    * finally we apply strong, emphasis, etc.

    """
    inlinePatterns = util.Registry()
    inlinePatterns.register(BacktickInlineProcessor(BACKTICK_RE), 'backtick', 190)
    inlinePatterns.register(EscapeInlineProcessor(ESCAPE_RE, md), 'escape', 180)
    inlinePatterns.register(ReferenceInlineProcessor(REFERENCE_RE, md), 'reference', 170)
    inlinePatterns.register(LinkInlineProcessor(LINK_RE, md), 'link', 160)
    inlinePatterns.register(ImageInlineProcessor(IMAGE_LINK_RE, md), 'image_link', 150)
    inlinePatterns.register(
        ImageReferenceInlineProcessor(IMAGE_REFERENCE_RE, md), 'image_reference', 140
    )
    inlinePatterns.register(
        ShortReferenceInlineProcessor(REFERENCE_RE, md), 'short_reference', 130
    )
    inlinePatterns.register(
        ShortImageReferenceInlineProcessor(IMAGE_REFERENCE_RE, md), 'short_image_ref', 125
    )
    inlinePatterns.register(AutolinkInlineProcessor(AUTOLINK_RE, md), 'autolink', 120)
    inlinePatterns.register(AutomailInlineProcessor(AUTOMAIL_RE, md), 'automail', 110)
    inlinePatterns.register(SubstituteTagInlineProcessor(LINE_BREAK_RE, 'br'), 'linebreak', 100)
    inlinePatterns.register(HtmlInlineProcessor(HTML_RE, md), 'html', 90)
    inlinePatterns.register(HtmlInlineProcessor(ENTITY_RE, md), 'entity', 80)
    inlinePatterns.register(DelimiterProcessor('*', 'strong,em', md), 'em_strong', 60)
    md.delimiters.add('_', 'strong,em', smart=True)
    return inlinePatterns


# The actual regular expressions for patterns
# -----------------------------------------------------------------------------

NOIMG = r'(?<!\!)'
""" Match not an image. Partial regular expression which matches if not preceded by `!`. """

BACKTICK_RE = r'(?:(?<!\\)((?:\\{2})+)(?=`+)|(?<!\\)`)'
""" Match backtick quoted string (`` `e=f()` `` or ``` ``e=f("`")`` ```). """

ESCAPE_RE = r'\\(.)'
""" Match a backslash escaped character (`\\<` or `\\*`). """

LINK_RE = NOIMG + r'\['
""" Match start of in-line link (`[text](url)` or `[text](<url>)` or `[text](url "title")`). """

IMAGE_LINK_RE = r'\!\['
""" Match start of in-line image link (`![alttxt](url)` or `![alttxt](<url>)`). """

REFERENCE_RE = LINK_RE
""" Match start of reference link (`[Label][3]`). """

IMAGE_REFERENCE_RE = IMAGE_LINK_RE
""" Match start of image reference (`![alt text][2]`). """

AUTOLINK_RE = r'<([A-Za-z][A-Za-z0-9+.-]*://[^<>]*)>'
""" Match an automatic link (`<http://www.example.com>`). """

AUTOMAIL_RE = r'<([^<> !]+@[^@<> ]+)>'
""" Match an automatic email link (`<me@example.com>`). """

HTML_RE = (
    # Tag
    r'''(<(\/?+[a-zA-Z][^\s"'<>@]*+(?:\s+[^\s"'=<>]++(?:\s*+=\s*+(?:"[^"]*+"|'[^']*+'|[^\s"'=<>]++))?+)*+\s*+/?|'''
    # Comment
    r'!--(?:(?!<!--|-->).)*--|'
    # Processing instruction
    r'[?](?:(?!<[?]|[?]>).)*[?]|'
    # `CDATA`
    r'!\[CDATA\[(?:(?!<!\[CDATA\[|\]\]>).)*\]\]'
    ')>)'
)
""" Match an HTML tag (`<...>`). """

ENTITY_RE = r'(&(?:\#[0-9]+|\#x[0-9a-fA-F]+|[a-zA-Z0-9]+);)'
""" Match an HTML entity (`&#38;` (decimal) or `&#x26;` (hex) or `&amp;` (named)). """

LINE_BREAK_RE = r'  \n'
""" Match two spaces at end of line. """


def dequote(string: str) -> str:
    """Remove quotes from around a string."""
    if ((string.startswith('"') and string.endswith('"')) or
       (string.startswith("'") and string.endswith("'"))):
        return string[1:-1]
    else:
        return string


class EmStrongItem(NamedTuple):
    """Emphasis/strong pattern item."""
    pattern: re.Pattern[str]
    builder: str
    tags: str


# The pattern classes
# -----------------------------------------------------------------------------


class Pattern:  # pragma: no cover
    """
    Base class that inline patterns subclass.

    Inline patterns are handled by means of `Pattern` subclasses, one per regular expression.
    Each pattern object uses a single regular expression and must support the following methods:
    [`getCompiledRegExp`][markdown.inlinepatterns.Pattern.getCompiledRegExp] and
    [`handleMatch`][markdown.inlinepatterns.Pattern.handleMatch].

    All the regular expressions used by `Pattern` subclasses must capture the whole block.  For this
    reason, they all start with `^(.*)` and end with `(.*)!`.  When passing a regular expression on
    class initialization, the `^(.*)` and `(.*)!` are added automatically and the regular expression
    is pre-compiled.

    It is strongly suggested that the newer style [`markdown.inlinepatterns.InlineProcessor`][] that
    use a more efficient and flexible search approach be used instead. However, the older style
    `Pattern` remains for backward compatibility with many existing third-party extensions.

    """

    ANCESTOR_EXCLUDES: Collection[str] = tuple()
    """
    A collection of elements which are undesirable ancestors. The processor will be skipped if it
    would cause the content to be a descendant of one of the listed tag names.
    """

    compiled_re: re.Pattern[str]
    md: Markdown | None

    def __init__(self, pattern: str, md: Markdown | None = None):
        """
        Create an instant of an inline pattern.

        Arguments:
            pattern: A regular expression that matches a pattern.
            md: An optional pointer to the instance of `markdown.Markdown` and is available as
                `self.md` on the class instance.


        """
        self.pattern = pattern
        self.compiled_re = re.compile(r"^(.*?)%s(.*)$" % pattern,
                                      re.DOTALL | re.UNICODE)

        self.md = md

    def getCompiledRegExp(self) -> re.Pattern:
        """ Return a compiled regular expression. """
        return self.compiled_re

    def handleMatch(self, m: re.Match[str]) -> etree.Element | str:
        """Return a ElementTree element from the given match.

        Subclasses should override this method.

        Arguments:
            m: A match object containing a match of the pattern.

        Returns: An ElementTree Element object.

        """
        pass  # pragma: no cover

    def type(self) -> str:
        """ Return class name, to define pattern type """
        return self.__class__.__name__

    def unescape(self, text: str) -> str:
        """ Return unescaped text given text with an inline placeholder. """
        try:
            stash = self.md.treeprocessors['inline'].stashed_nodes
        except KeyError:  # pragma: no cover
            return text

        def get_stash(m):
            id = m.group(1)
            if id in stash:
                value = stash.get(id)
                if isinstance(value, str):
                    return value
                else:
                    # An `etree` Element - return text content only
                    return ''.join(value.itertext())
        return util.INLINE_PLACEHOLDER_RE.sub(get_stash, text)


class InlineProcessor(Pattern):
    """
    Base class that inline processors subclass.

    This is the newer style inline processor that uses a more
    efficient and flexible search approach.

    """

    def __init__(self, pattern: str, md: Markdown | None = None):
        """
        Create an instant of an inline processor.

        Arguments:
            pattern: A regular expression that matches a pattern.
            md: An optional pointer to the instance of `markdown.Markdown` and is available as
                `self.md` on the class instance.

        """
        self.pattern = pattern
        self.compiled_re = re.compile(pattern, re.DOTALL | re.UNICODE)

        # API for Markdown to pass `safe_mode` into instance
        self.safe_mode = False
        self.md = md

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element | str | None, int | None, int | None]:
        """Return a ElementTree element from the given match and the
        start and end index of the matched text.

        If `start` and/or `end` are returned as `None`, it will be
        assumed that the processor did not find a valid region of text.

        Subclasses should override this method.

        Arguments:
            m: A re match object containing a match of the pattern.
            data: The buffer currently under analysis.

        Returns:
            el: The ElementTree element, text or None.
            start: The start of the region that has been matched or None.
            end: The end of the region that has been matched or None.

        """
        pass  # pragma: no cover


class SimpleTextPattern(Pattern):  # pragma: no cover
    """ Return a simple text of `group(2)` of a Pattern. """
    def handleMatch(self, m: re.Match[str]) -> str:
        """ Return string content of `group(2)` of a matching pattern. """
        return m.group(2)


class SimpleTextInlineProcessor(InlineProcessor):
    """ Return a simple text of `group(1)` of a Pattern. """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[str, int, int]:
        """ Return string content of `group(1)` of a matching pattern. """
        return m.group(1), m.start(0), m.end(0)


class EscapeInlineProcessor(InlineProcessor):
    """ Return an escaped character. """

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[str | None, int, int]:
        """
        If the character matched by `group(1)` of a pattern is in [`ESCAPED_CHARS`][markdown.Markdown.ESCAPED_CHARS]
        then return the integer representing the character's Unicode code point (as returned by [`ord`][]) wrapped
        in [`util.STX`][markdown.util.STX] and [`util.ETX`][markdown.util.ETX].

        If the matched character is not in [`ESCAPED_CHARS`][markdown.Markdown.ESCAPED_CHARS], then return `None`.
        """

        char = m.group(1)
        if char in self.md.ESCAPED_CHARS:
            return '{}{}{}'.format(util.STX, ord(char), util.ETX), m.start(0), m.end(0)
        else:
            return None, m.start(0), m.end(0)


class SimpleTagPattern(Pattern):  # pragma: no cover
    """
    Return element of type `tag` with a text attribute of `group(3)`
    of a Pattern.

    """
    def __init__(self, pattern: str, tag: str):
        """
        Create an instant of an simple tag pattern.

        Arguments:
            pattern: A regular expression that matches a pattern.
            tag: Tag of element.

        """
        Pattern.__init__(self, pattern)
        self.tag = tag
        """ The tag of the rendered element. """

    def handleMatch(self, m: re.Match[str]) -> etree.Element:
        """
        Return [`Element`][xml.etree.ElementTree.Element] of type `tag` with the string in `group(3)` of a
        matching pattern as the Element's text.
        """
        el = etree.Element(self.tag)
        el.text = m.group(3)
        return el


class SimpleTagInlineProcessor(InlineProcessor):
    """
    Return element of type `tag` with a text attribute of `group(2)`
    of a Pattern.

    """
    def __init__(self, pattern: str, tag: str):
        """
        Create an instant of an simple tag processor.

        Arguments:
            pattern: A regular expression that matches a pattern.
            tag: Tag of element.

        """
        InlineProcessor.__init__(self, pattern)
        self.tag = tag
        """ The tag of the rendered element. """

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element, int, int]:  # pragma: no cover
        """
        Return [`Element`][xml.etree.ElementTree.Element] of type `tag` with the string in `group(2)` of a
        matching pattern as the Element's text.
        """
        el = etree.Element(self.tag)
        el.text = m.group(2)
        return el, m.start(0), m.end(0)


class SubstituteTagPattern(SimpleTagPattern):  # pragma: no cover
    """ Return an element of type `tag` with no children. """
    def handleMatch(self, m: re.Match[str]) -> etree.Element:
        """ Return empty [`Element`][xml.etree.ElementTree.Element] of type `tag`. """
        return etree.Element(self.tag)


class SubstituteTagInlineProcessor(SimpleTagInlineProcessor):
    """ Return an element of type `tag` with no children. """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element, int, int]:
        """ Return empty [`Element`][xml.etree.ElementTree.Element] of type `tag`. """
        return etree.Element(self.tag), m.start(0), m.end(0)


class BacktickInlineProcessor(InlineProcessor):
    """ Return a `<code>` element containing the escaped matching text. """

    def __init__(self, pattern: str):
        InlineProcessor.__init__(self, pattern)
        self.ESCAPED_BSLASH = '{}{}{}'.format(util.STX, ord('\\'), util.ETX)
        self.tag = 'code'
        """ The tag of the rendered element. """

    def find_code_spans(self, start: int, text: str) -> tuple[int, int | None]:
        """Find code spans."""

        last = len(text)

        # Get the maximum starting ticks
        max_ticks = 0
        while start < last and text[start] == '`':
            max_ticks += 1
            start += 1

        longest_span = 0
        end = 0

        # Find an ending span of backticks that matches our opening
        i = start
        while i < last:
            span_length = 0
            while i < last and text[i] == '`':
                span_length += 1
                i += 1
            if not span_length:
                i += 1
                continue

            # Did we find the end?
            if max_ticks == span_length:
                return start, i - span_length

            # Track the longest span of backticks we find as a fallback.
            if span_length > longest_span:
                longest_span = span_length
                end = i

        # Since we didn't find an exact matching start and end,
        # adjust start to match the largest end we could calculate.
        if 0 < longest_span < max_ticks:
            return start - (max_ticks - longest_span), end - longest_span

        # We could not find a suitable pairing
        return start + max_ticks, None

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element | str | None, int | None, int | None]:
        """
        If the match contains `group(3)` of a pattern, then return a `code`
        [`Element`][xml.etree.ElementTree.Element] which contains HTML escaped text (with
        [`code_escape`][markdown.util.code_escape]) as an [`AtomicString`][markdown.util.AtomicString].

        If the match contains `group(1)` then return the text of `group(1)` as backslash escaped.

        """
        if m.group(1):
            return m.group(1).replace('\\\\', self.ESCAPED_BSLASH), m.start(0), m.end(0)

        begin = m.start(0)
        start, end = self.find_code_spans(begin, data)
        if end is not None:
            el = etree.Element(self.tag)
            el.text = util.AtomicString(util.code_escape(data[start:end].strip()))
            return el, begin, end + (start - begin)
        # Skip over backtick group as we could find no match
        return None, begin, start


class DoubleTagPattern(SimpleTagPattern):  # pragma: no cover
    """Return a ElementTree element nested in tag2 nested in tag1.

    Useful for strong emphasis etc.

    """
    def handleMatch(self, m: re.Match[str]) -> etree.Element:
        """
        Return [`Element`][xml.etree.ElementTree.Element] in following format:
        `<tag1><tag2>group(3)</tag2>group(4)</tag2>` where `group(4)` is optional.

        """
        tag1, tag2 = self.tag.split(",")
        el1 = etree.Element(tag1)
        el2 = etree.SubElement(el1, tag2)
        el2.text = m.group(3)
        if len(m.groups()) == 5:
            el2.tail = m.group(4)
        return el1


class DoubleTagInlineProcessor(SimpleTagInlineProcessor):
    """Return a ElementTree element nested in tag2 nested in tag1.

    Useful for strong emphasis etc.

    """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element, int, int]:  # pragma: no cover
        """
        Return [`Element`][xml.etree.ElementTree.Element] in following format:
        `<tag1><tag2>group(2)</tag2>group(3)</tag2>` where `group(3)` is optional.

        """
        tag1, tag2 = self.tag.split(",")
        el1 = etree.Element(tag1)
        el2 = etree.SubElement(el1, tag2)
        el2.text = m.group(2)
        if len(m.groups()) == 3:
            el2.tail = m.group(3)
        return el1, m.start(0), m.end(0)


class HtmlInlineProcessor(InlineProcessor):
    """ Store raw inline html and return a placeholder. """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[str, int, int]:
        """ Store the text of `group(1)` of a pattern and return a placeholder string. """
        rawhtml = self.backslash_unescape(self.unescape(m.group(1)))
        place_holder = self.md.htmlStash.store(rawhtml)
        return place_holder, m.start(0), m.end(0)

    def unescape(self, text: str) -> str:
        """ Return unescaped text given text with an inline placeholder. """
        try:
            stash = self.md.treeprocessors['inline'].stashed_nodes
        except KeyError:  # pragma: no cover
            return text

        def get_stash(m: re.Match[str]) -> str:
            id = m.group(1)
            value = stash.get(id)
            if value is not None:
                if isinstance(value, etree.Element):
                    # Ensure we don't have a placeholder inside a placeholder
                    return self.unescape(self.md.serializer(value))
                else:
                    return r'\%s' % value

        return util.INLINE_PLACEHOLDER_RE.sub(get_stash, text)

    def backslash_unescape(self, text: str) -> str:
        """ Return text with backslash escapes undone (backslashes are restored). """
        try:
            RE = self.md.treeprocessors['unescape'].RE
        except KeyError:  # pragma: no cover
            return text

        def _unescape(m: re.Match[str]) -> str:
            return chr(int(m.group(1)))

        return RE.sub(_unescape, text)


class EvaluatedText(str):
    """
    Text that sits between delimiter regions that were parsed together.

    Python Markdown processes the tail of an element we return starting with the same pattern that created it
    and pass it back to us while we still have regions cached. All delimiters in it have already been evaluated,
    so this represents text we can ignore.
    """


class Delimiter:
    """Delimiter."""

    def __init__(self, token: str, tags: str, smart: bool, double: bool):
        """Initialize."""

        # An unclosed delimiter.
        #
        # 0. Start position of the (remaining) run in the text.
        # 1. End position of the (remaining) run in the text.
        # 2. Whether the run is ambiguous (could be a start or an end).
        # 3. Original length of the run.
        # 4. Current length of the run.
        self.stack: deque[tuple[int, int, bool, int, int]] = deque()
        temp = tags.split(',')
        self.tag_count = len(temp)
        self.tags: tuple[str, str] = (temp[0], temp[1]) if self.tag_count == 2 else (temp[0], temp[0])
        self.double = len(temp) != 2 and double
        self.single = len(temp) != 2 and not double
        self.smart = smart
        self._build_patterns(token)

    def _build_patterns(self, token: str) -> str:
        """Build regular expression patterns."""

        # Build up patterns
        self.token = token
        etoken = re.escape(token)
        # Avoid at start and end
        xstart = fr'(?:(?<=_)|(?<![\w{etoken}]))' if token != '_' else fr'(?<![\w{etoken}])'
        xend = fr'(?:(?=_)|(?![\w{etoken}]))' if token != '_' else fr'(?![\w{etoken}])'
        self.max_size = 2
        if self.tag_count != 2 and not self.double:
            self.max_size = 1

        # Patterns for "smart" cases.
        if self.smart:
            self.boundary = re.compile(
                fr'''(?x)
                (?P<ambiguous>(?<!^)(?<![\s{etoken}]){xstart}{etoken}{{1,}}{xend}(?![\s{etoken}])(?!$))|
                (?P<end>(?<!^)(?<![\s{etoken}]){etoken}{{1,}}{xend})|
                (?P<start>{xstart}{etoken}{{1,}}(?![\s{etoken}])(?!$))
                ''',
                flags=re.UNICODE
            )
        # Patterns for "dumb" cases.
        else:
            self.boundary = re.compile(
                fr'''(?x)
                (?P<ambiguous>(?<!^)(?<![\s{etoken}]){etoken}{{1,}}(?![\s{etoken}])(?!$))|
                (?P<end>(?<!^)(?<![\s{etoken}]){etoken}{{1,}})|
                (?P<start>{etoken}{{1,}}(?![\s{etoken}])(?!$))
                ''',
                flags=re.UNICODE
            )

        self.bad = re.compile(fr'{etoken}+')

        return fr'{etoken}'

    def reset(self) -> None:
        """Reset."""

        # Cache info
        self.stack.clear()


class DelimiterProcessor(InlineProcessor):
    """Processor for handling complex nested patterns such as strong and em matches."""

    SPACE = re.compile(r'\s')

    def __init__(
        self,
        token: str,
        tags: str,
        md: Markdown,
        smart: bool = False,
        double: bool = False
    ) -> None:
        """Initialize."""

        md.delimiters = self
        self.regions: list[tuple[int, int, int, int, tuple[str, str], int]] = []
        # Unpaired delimiter. The entries are the same as `Delimiter.stack`.
        # HTML element cache of valid regions. Each entry holds the element, the location it replaces,
        # and the location of the token Python Markdown will call us for once the element has been replaced.
        self.cache: list[tuple[etree.Element, int, int, int]] = []
        # The entries are the same as `Delimiter.stack`.
        self.stack: list[tuple[int, int, bool, int, int]] = []
        # Position of every delimiter token (valid or not) encountered while pairing, in ascending order.
        self.positions: list[int] = []
        # For each token and run length, how deep the last failed rule of 3 search went and the entry at that depth.
        self.searched: dict[tuple[str, int], tuple[int, tuple[int, int, bool, int, int]]] = {}
        self.tokens: list[str] = []
        self.delimiters: dict[str, Delimiter] = {}
        self.cache_index = 0
        self.cache_pos = 0
        # Info about the unused part of a closing delimiter run that directly follows the last returned element
        self.remainder: tuple[str, str] | None = None
        self.md = md
        # API for Markdown to pass `safe_mode` into instance
        self.safe_mode = False
        self.add(token, tags, smart, double)

    def add(
        self,
        token: str,
        tags: str,
        smart: bool = False,
        double: bool = False
    ) -> None:
        """Add a delimiter."""

        if token not in self.tokens:
            self.tokens.append(token)
        self.delimiters[token] = Delimiter(token, tags, smart, double)
        self.pattern = '|'.join([re.escape(t) for t in self.tokens])
        self.compiled_re = re.compile(self.pattern, re.DOTALL | re.UNICODE)

    def remove(self, token: str) -> None:
        """Remove a token."""

        try:
            i = self.tokens.index(token)
            del self.tokens[i]
            del self.delimiters[token]
        except Exception:
            pass
        self.pattern = '|'.join([re.escape(t) for t in self.tokens])
        self.compiled_re = re.compile(self.pattern, re.DOTALL | re.UNICODE) if self.pattern else re.compile(r'(?!)')

    def reset(self) -> None:
        """Reset."""

        # Cache info
        for v in self.delimiters.values():
            v.reset()
        self.regions.clear()
        self.cache.clear()
        self.stack.clear()
        self.positions.clear()
        self.searched.clear()
        self.cache_index = 0
        self.cache_pos = 0
        self.remainder = None

    def _build_element(
        self,
        data: str,
        start: int = 0
    ) -> tuple[etree.Element, int]:
        """Element builder."""

        regions = self.regions
        el: etree.Element | None = None
        last: Any = None
        previous: Any = None

        outer: list[etree.Element] = []
        outer_r: list[tuple[int, int, int, int, tuple[str, str], int]] = []

        # Iterate regions creating the elements they represent
        end = len(regions)
        idx = 0
        for idx, i in enumerate(range(start, end), 1):
            r = regions[i]
            # Not contained within region
            if idx and r[0] >= regions[start][3]:
                idx -= 1
                break

            # Get the appropriate element(s)
            if r[-1] == 2:
                el1 = etree.Element(r[4][0])
            else:
                el1 = etree.Element(r[4][1])

            # Populate the elements with their text
            if idx > 1:
                if last.text is None:
                    if previous[2] < r[0]:
                        last.text = data[previous[1]:previous[2]]
                    else:
                        last.text = data[previous[1]:r[0]]
                if last is not outer[-1] and last.tail is None:
                    if r[0] < outer_r[-1][3]:
                        last.tail = EvaluatedText(data[previous[3]:r[0]])
                    else:
                        last.tail = EvaluatedText(data[previous[3]:outer_r[-1][2]])
                        outer[-1].tail = EvaluatedText(data[outer_r[-1][3]:r[0]])

            # First element
            if el is None:
                el = el1
                last = el
                outer.append(el)
                outer_r.append(r)

            # Subsequent elements
            else:
                # Is the current outer element no longer wrapping this one?
                while len(outer_r) > 1 and r[3] > outer_r[-1][3]:
                    outer.pop()
                    outer_r.pop()

                # Non-nested
                else:
                    outer[-1].append(el1)

                # Is this element wrapping the next?
                if i + 1 < end:
                    if r[3] > regions[i + 1][3]:
                        outer.append(el1)
                        outer_r.append(r)

                # Track the last element we parsed.
                last = el1

            # Track the previous region.
            previous = r

        # Populate remaining elements with their text
        while outer:
            if last.text is None:
                last.text = data[previous[1]:previous[2]]
            if last.tail is None and last is not outer[-1]:
                last.tail = EvaluatedText(data[previous[3]:outer_r[-1][2]])
            last = outer.pop()
            previous = outer_r.pop()

        return cast('etree.Element', el), idx

    def build_cache(self, data: str) -> None:
        """
        Build the elements for all the regions we found.

        Elements are built from the data as it is now, so there is nothing to recalculate when Python Markdown
        asks for them.

        While pairing, we encounter every token between the regions we found, whether it was useful or not.
        Python Markdown will call us for each of them, so the call after an element is replaced will be for the first
        token at or after the end of that element. If an element only used part of a delimiter run, the rest
        of the run is that token.
        """

        regions = self.regions
        index = 0
        position = 0
        while index < len(regions):
            el, count = self._build_element(data, index)
            start, end = regions[index][0], regions[index][3]
            if data[end:end + 1] in self.delimiters:
                anchor = end
            else:
                position = bisect_left(self.positions, end, position)
                anchor = self.positions[position] if position < len(self.positions) else end
            self.cache.append((el, start, end, anchor))
            index += count

        regions.clear()
        self.positions.clear()
        self.cache_index = 0

    def get_cached_result(self, pos: int | None = None) -> tuple[etree.Element, int, int]:
        """Get the next element from the cache."""

        el, start, end, anchor = self.cache[self.cache_index]
        offset = 0 if pos is None else pos - self.cache_pos
        self.cache_index += 1

        if self.cache_index < len(self.cache):
            self.cache_pos = anchor
        # Nothing left to process
        else:
            self.reset()

        return el, start + offset, end + offset

    @staticmethod
    def rule_of_3(opener: int, closer: int) -> bool:
        """
        Check the "rule of 3" which prevents an open delimiter from pairing with an ambiguous one.

        The original lengths of the delimiter must be used, not what is left of them after partial pairing.
        """

        return (opener + closer) % 3 == 0 and (opener % 3 != 0 or closer % 3 != 0)

    def get_match(self, data: str, start: int) -> re.Match[str] | None:
        """Get match."""

        for d in self.delimiters.values():
            m = d.boundary.match(data, start)
            if m is not None:
                return m
        return None

    def search(self, data: str, start: int) -> re.Match[str] | None:
        """Search."""

        for i in range(start, len(data)):
            if data[i] in self.delimiters:
                self.positions.append(i)
                d = self.delimiters[data[i]]
                m = d.boundary.match(data, i)
                if m is not None:
                    if not d.stack and m.lastgroup[0] == 'e':  # type: ignore[index]
                        continue
                    return m
        return None

    def add_region(self, delim: Delimiter, a: int, b: int, c: int, d: int, size: int) -> None:
        """Add region."""

        self.regions.append((a, b, c, d, delim.tags, size))
        # Unpaired delimiters inside the new region can no longer be used, drop them
        for other in self.delimiters.values():
            while other.stack:
                p = other.stack[-1][0]
                if max(p, a) <= min(p, d - 1):
                    other.stack.pop()
                    continue
                break

    def handleMatch(  # type: ignore[override]
        self,
        m: re.Match[str],
        data: str
    ) -> tuple[etree.Element | None, int | None, int | None]:
        """Parse delimiter pattern."""

        remainder = self.remainder
        self.remainder = None
        el, start, end = self._handle_match(m, data, remainder)

        # If the element did not consume the entire closing delimiter run, the rest of the run directly follows
        # the placeholder that will replace the element. The placeholder will hide what preceded the run, which
        # is needed to correctly classify the rest of the run, so save it for the next match.
        if el is not None and end is not None and end < len(data) and data[end] == data[end - 1]:
            run = end - 1
            while run > 0 and data[run - 1] == data[end]:
                run -= 1
            if run > 0:
                self.remainder = (data[end], data[run - 1])

        return el, start, end

    def _handle_match(
        self,
        m: re.Match[str],
        data: str,
        remainder: tuple[str, str] | None
    ) -> tuple[etree.Element | None, int | None, int | None]:
        """Parse delimiter pattern."""

        # If the cache is not empty, it is possible to receive text that we already evaluated
        # between found regions, ignore such text.
        if self.cache and isinstance(data, EvaluatedText):
            skip = self.delimiters[m.group(0)].bad.match(data, m.start(0))
            return None, m.start(0), skip.end(0) if skip else m.end(0)

        # Do we have entries we haven't returned yet?
        if self.cache:
            return self.get_cached_result(m.start(0))

        # If token is not an opening, quit
        # If this is the rest of a closing run that was partially consumed, the placeholder directly before it can
        # change how the run is classified, but the run should be classified by what actually preceded it.
        text = data
        pos = m.start(0)
        if remainder is not None and pos and data[pos - 1] == '\x03' and data[pos] == remainder[0]:
            text = f'{data[:pos - 1]}{remainder[1]}{data[pos:]}'

        m2 = self.get_match(text, pos)
        if m2 is None or m2.lastgroup[0] == 'e':  # type: ignore[index]
            if m2 is None:
                delim = self.delimiters[m.group(0)]
                m2 = delim.bad.match(data, m.start(0))
            # Advance past the full length of the delimiter found
            return None, m2.start(0), m2.end(0)

        # Get the stack and regions
        token = data[m.start(0)]
        delim = self.delimiters[token]
        stack = delim.stack

        start = m2.start(0)
        end = m2.end(0)
        length = end - start

        # Double needs at least a size of 2
        if delim.double and length < 2:
            return None, m.start(0), m.end(0)

        is_ambiguous = m2.lastgroup[0] != 's'  # type: ignore[index]
        stack.append((start, start + length, is_ambiguous, length, length))

        # Pair tokens until the stack is empty or we can no longer find tokens.
        while any(d.stack for d in self.delimiters.values()):
            m2 = self.search(data, end)
            if m2 is None:
                break

            token = data[m2.start(0)]
            delim = self.delimiters[token]
            stack = delim.stack

            start = m2.start(0)
            end = m2.end(0)

            # Get current and last delimiter size
            current = len(m2.group(0))

            # Some delimiters may be ambiguous and look like both a start or an end
            is_start = m2.lastgroup[0] != 'e'  # type: ignore[index]
            is_end = not is_start or m2.lastgroup[0] != 's'  # type: ignore[index]
            is_ambiguous = is_start and is_end

            last = stack[-1][-1] if stack else 0

            # Rule of 3: an ambiguous delimiter cannot pair with an open delimiter if the sum of the
            # original lengths is a multiple of 3 (unless both are multiples of 3).
            if (
                stack and is_ambiguous and current != last and
                self.rule_of_3(stack[-1][3], current)
            ):
                # Skip the entries an earlier search for this length already ruled out. They are unchanged
                # as long as the last of them is still in place, as entries are only ever appended or popped.
                lowest = 0
                key = (token, current)
                if key in self.searched:
                    depth, entry = self.searched[key]
                    if depth < len(stack) and stack[depth - 1] is entry:
                        lowest = depth
                for i in range(len(stack) - 2, lowest - 1, -1):
                    if stack[i][-1] == current and not self.rule_of_3(stack[i][3], current):
                        while len(stack) > i + 1:
                            stack.pop()
                        last = current
                        break
                else:
                    if len(stack) > 1:
                        self.searched[key] = (len(stack) - 1, stack[-2])

            # Find closing tokens
            # Looking for:
            # - `*em*`
            # - `**strong**`
            # - `***strong,em***`
            # - `*em**`
            # - `*em***`
            # - `**strong***`
            #
            # Avoid ambiguous tokens that could be a start or an end.
            # Consume starts until the end token is fully consumed.
            # If we don't consume the entire end, see if next rule consumes it.
            if stack and is_end and (
                (current > last and (not is_ambiguous or not self.rule_of_3(stack[-1][3], current))) or
                current == last or current >= 3
            ):
                is_start = False

                # Consume previous points until the delimiter is consumed
                original = current
                while stack and current and last <= current:
                    delimiter = stack.pop()

                    # Build up region for pair and adjust accounting.
                    size = min(delimiter[-1], 1 if delim.tag_count == 2 and delimiter[-1] == 3 else delim.max_size)
                    self.add_region(delim, delimiter[1] - size, delimiter[1], start, start + size, size)
                    start += size
                    current -= size
                    new = 0
                    if size < delimiter[-1] and (not delim.double or (delimiter[-1] - size) != 1):
                        new = delimiter[-1] - size
                        stack.append((delimiter[0], delimiter[1] - size, delimiter[2], delimiter[3], new))

                    if not stack:
                        if any(d.stack for d in self.delimiters.values() if d is not delim):
                            delim.reset()
                            continue
                        is_end = False
                        break

                    last = stack[-1][-1]

                # Should remainder be treated as a new start?
                if original >= 3 and current and is_ambiguous:
                    delim.stack.append((m2.start(0) + (original - current), end, False, original, current))
                    is_end = False

                # Do we still have more to consume?
                else:
                    is_end = current and stack and last > current

            # Looking for:
            # - `***em*`
            # - `***strong**`
            # - `**em*`
            if stack and is_end and (last >= 3 or not is_ambiguous) and last > current:
                delimiter = stack.pop()

                # Don't pair with an ambiguous opening
                while stack and delimiter[-1] != 3 and delimiter[2]:
                    delimiter = stack.pop()
                    last = delimiter[-1]

                if delimiter[2] and delimiter[-1] != 3:
                    if any(d.stack for d in self.delimiters.values() if d is not delim):
                        delim.reset()
                        continue
                    break

                # Create new regions
                is_start = False
                ds, de = delimiter[:2]
                while current and (not delim.double or current != 1):
                    size = min(current, 1 if delim.tag_count == 2 and current == 3 else delim.max_size)
                    new = last - size
                    self.add_region(delim, ds + new, de, start, start + size, size)
                    start += size
                    current -= size
                    last -= size
                    de -= size
                if last and (not delim.double or last > 1):
                    stack.append((ds, de, False,  delimiter[3], last))

            # Find opening tokens
            # Looking for:
            # - `*em ...*`
            # - `**strong ...*`
            # - `***em ...*`
            if is_start and (not delim.double or current != 1):
                stack.append((start, end, is_ambiguous, current, current))

        # Combine the stacks and order them
        for delim in self.delimiters.values():
            self.stack.extend(delim.stack)
        self.stack.sort(key=lambda x: x[0])

        # Build the HTML elements
        if self.regions:
            # Regions may be out of order.
            self.regions.sort(key=lambda x: x[0])
            self.build_cache(data)
            return self.get_cached_result()

        # We failed to pair any valid start/end delimiters, avoid the parsed range next pass.
        start = m.start(0)
        end = self.stack[-1][1] if self.stack else m.end(0)
        self.reset()
        return None, start, end


class LinkInlineProcessor(InlineProcessor):
    """ Return a link element from the given match. """
    RE_LINK = re.compile(r'''\(\s*(?:(<[^<>]*>)\s*(?:('[^']*'|"[^"]*")\s*)?\))?''', re.DOTALL | re.UNICODE)
    RE_TITLE_CLEAN = re.compile(r'\s')

    def __init__(self, pattern: str, md: Markdown | None = None):
        super().__init__(pattern, md)
        # The text `getText` last saw and the closing bracket for each index of it.
        self._bracket_data: str | None = None
        self._bracket_ends: list[int | None] = []

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element | None, int | None, int | None]:
        """ Return an `a` [`Element`][xml.etree.ElementTree.Element] or `(None, None, None)`. """
        text, index, handled = self.getText(data, m.end(0))

        if not handled:
            return None, None, None

        href, title, index, handled = self.getLink(data, index)
        if not handled:
            return None, None, None

        el = etree.Element("a")
        el.text = text

        el.set("href", href)

        if title is not None:
            el.set("title", title)

        return el, m.start(0), index

    def getLink(self, data: str, index: int) -> tuple[str, str | None, int, bool]:
        """Parse data between `()` of `[Text]()` allowing recursive `()`. """

        href = ''
        title: str | None = None
        handled = False

        m = self.RE_LINK.match(data, pos=index)
        if m and m.group(1):
            # Matches [Text](<link> "title")
            href = m.group(1)[1:-1].strip()
            if m.group(2):
                title = m.group(2)[1:-1]
            index = m.end(0)
            handled = True
        elif m:
            # Track bracket nesting and index in string
            bracket_count = 1
            backtrack_count = 1
            start_index = m.end()
            index = start_index
            last_bracket = -1

            # Primary (first found) quote tracking.
            quote: str | None = None
            start_quote = -1
            exit_quote = -1
            ignore_matches = False

            # Secondary (second found) quote tracking.
            alt_quote = None
            start_alt_quote = -1
            exit_alt_quote = -1

            # Track last character
            last = ''

            for pos in range(index, len(data)):
                c = data[pos]
                if c == '(':
                    # Count nested (
                    # Don't increment the bracket count if we are sure we're in a title.
                    if not ignore_matches:
                        bracket_count += 1
                    elif backtrack_count > 0:
                        backtrack_count -= 1
                elif c == ')':
                    # Match nested ) to (
                    # Don't decrement if we are sure we are in a title that is unclosed.
                    if ((exit_quote != -1 and quote == last) or (exit_alt_quote != -1 and alt_quote == last)):
                        bracket_count = 0
                    elif not ignore_matches:
                        bracket_count -= 1
                    elif backtrack_count > 0:
                        backtrack_count -= 1
                        # We've found our backup end location if the title doesn't resolve.
                        if backtrack_count == 0:
                            last_bracket = index + 1

                elif c in ("'", '"'):
                    # Quote has started
                    if not quote:
                        # We'll assume we are now in a title.
                        # Brackets are quoted, so no need to match them (except for the final one).
                        ignore_matches = True
                        backtrack_count = bracket_count
                        bracket_count = 1
                        start_quote = index + 1
                        quote = c
                    # Secondary quote (in case the first doesn't resolve): [text](link'"title")
                    elif c != quote and not alt_quote:
                        start_alt_quote = index + 1
                        alt_quote = c
                    # Update primary quote match
                    elif c == quote:
                        exit_quote = index + 1
                    # Update secondary quote match
                    elif alt_quote and c == alt_quote:
                        exit_alt_quote = index + 1

                index += 1

                # Link is closed, so let's break out of the loop
                if bracket_count == 0:
                    # Get the title if we closed a title string right before link closed
                    if exit_quote >= 0 and quote == last:
                        href = data[start_index:start_quote - 1]
                        title = ''.join(data[start_quote:exit_quote - 1])
                    elif exit_alt_quote >= 0 and alt_quote == last:
                        href = data[start_index:start_alt_quote - 1]
                        title = ''.join(data[start_alt_quote:exit_alt_quote - 1])
                    else:
                        href = data[start_index:index - 1]
                    break

                if c != ' ':
                    last = c

            # We have a scenario: `[test](link"notitle)`
            # When we enter a string, we stop tracking bracket resolution in the main counter,
            # but we do keep a backup counter up until we discover where we might resolve all brackets
            # if the title string fails to resolve.
            if bracket_count != 0 and backtrack_count == 0:
                href = data[start_index:last_bracket - 1]
                index = last_bracket
                bracket_count = 0

            handled = bracket_count == 0

        if title is not None:
            title = self.RE_TITLE_CLEAN.sub(' ', dequote(self.unescape(title.strip())))

        href = self.unescape(href).strip()

        return href, title, index, handled

    def getText(self, data: str, index: int) -> tuple[str, int, bool]:
        """Parse the content between `[]` of the start of an image or link
        resolving nested square brackets.

        """
        # Scanning forward from every `[` is quadratic when the brackets do not
        # close, so find the closing bracket for every index of `data` at once.
        if self._bracket_data is not data:
            self._bracket_data = data
            self._bracket_ends = self._findBracketEnds(data)
        end = self._bracket_ends[index]
        if end is None:
            return data[index:], len(data), False
        return data[index:end - 1], end, True

    @staticmethod
    def _findBracketEnds(data: str) -> list[int | None]:
        """
        For each index of `data`, return the index just past the `]` which closes an
        opening bracket before that index, or `None` if the bracket never closes.

        """
        ends: list[int | None] = [None] * (len(data) + 1)
        depth = 0
        # `stack` holds the indexes still waiting for a closing bracket. The bracket
        # depth before each one is strictly increasing from bottom to top.
        stack: list[tuple[int, int]] = []
        for pos in range(len(data) + 1):
            while stack and depth < stack[-1][1]:
                ends[stack.pop()[0]] = pos
            stack.append((pos, depth))
            if pos < len(data):
                if data[pos] == '[':
                    depth += 1
                elif data[pos] == ']':
                    depth -= 1
        return ends


class ImageInlineProcessor(LinkInlineProcessor):
    """ Return a `img` element from the given match. """

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element | None, int | None, int | None]:
        """ Return an `img` [`Element`][xml.etree.ElementTree.Element] or `(None, None, None)`. """
        text, index, handled = self.getText(data, m.end(0))
        if not handled:
            return None, None, None

        src, title, index, handled = self.getLink(data, index)
        if not handled:
            return None, None, None

        el = etree.Element("img")

        el.set("src", src)

        if title is not None:
            el.set("title", title)

        el.set('alt', self.unescape(text))
        return el, m.start(0), index


class ReferenceInlineProcessor(LinkInlineProcessor):
    """ Match to a stored reference and return link element. """
    NEWLINE_CLEANUP_RE = re.compile(r'\s+', re.MULTILINE)

    RE_LINK = re.compile(r'\s?\[([^\]]*)\]', re.DOTALL | re.UNICODE)

    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element | None, int | None, int | None]:
        """
        Return [`Element`][xml.etree.ElementTree.Element] returned by `makeTag` method or `(None, None, None)`.

        """
        text, index, handled = self.getText(data, m.end(0))
        if not handled:
            return None, None, None

        id, end, handled = self.evalId(data, index, text)
        if not handled:
            return None, None, None

        # Clean up line breaks in id
        id = self.NEWLINE_CLEANUP_RE.sub(' ', id)
        if id not in self.md.references:  # ignore undefined refs
            return None, m.start(0), end

        href, title = self.md.references[id]

        return self.makeTag(href, title, text), m.start(0), end

    def evalId(self, data: str, index: int, text: str) -> tuple[str | None, int, bool]:
        """
        Evaluate the id portion of `[ref][id]`.

        If `[ref][]` use `[ref]`.
        """
        m = self.RE_LINK.match(data, pos=index)
        if not m:
            return None, index, False
        else:
            id = m.group(1).lower()
            end = m.end(0)
            if not id:
                id = text.lower()
        return id, end, True

    def makeTag(self, href: str, title: str, text: str) -> etree.Element:
        """ Return an `a` [`Element`][xml.etree.ElementTree.Element]. """
        el = etree.Element('a')

        el.set('href', href)
        if title:
            el.set('title', title)

        el.text = text
        return el


class ShortReferenceInlineProcessor(ReferenceInlineProcessor):
    """Short form of reference: `[google]`. """
    def evalId(self, data: str, index: int, text: str) -> tuple[str, int, bool]:
        """Evaluate the id of `[ref]`.  """

        return text.lower(), index, True


class ImageReferenceInlineProcessor(ReferenceInlineProcessor):
    """ Match to a stored reference and return `img` element. """
    def makeTag(self, href: str, title: str, text: str) -> etree.Element:
        """ Return an `img` [`Element`][xml.etree.ElementTree.Element]. """
        el = etree.Element("img")
        el.set("src", href)
        if title:
            el.set("title", title)
        el.set("alt", self.unescape(text))
        return el


class ShortImageReferenceInlineProcessor(ImageReferenceInlineProcessor):
    """ Short form of image reference: `![ref]`. """
    def evalId(self, data: str, index: int, text: str) -> tuple[str, int, bool]:
        """Evaluate the id of `[ref]`.  """

        return text.lower(), index, True


class AutolinkInlineProcessor(InlineProcessor):
    """ Return a link Element given an auto-link (`<http://example/com>`). """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element, int, int]:
        """ Return an `a` [`Element`][xml.etree.ElementTree.Element] of `group(1)`. """
        el = etree.Element("a")
        el.set('href', self.unescape(m.group(1)))
        el.text = util.AtomicString(m.group(1))
        return el, m.start(0), m.end(0)


class AutomailInlineProcessor(InlineProcessor):
    """
    Return a `mailto` link Element given an auto-mail link (`<foo@example.com>`).
    """
    def handleMatch(self, m: re.Match[str], data: str) -> tuple[etree.Element, int, int]:
        """ Return an [`Element`][xml.etree.ElementTree.Element] containing a `mailto` link  of `group(1)`. """
        el = etree.Element('a')
        email = self.unescape(m.group(1))
        if email.startswith("mailto:"):
            email = email[len("mailto:"):]

        def codepoint2name(code: int) -> str:
            """Return entity definition by code, or the code if not defined."""
            entity = entities.codepoint2name.get(code)
            if entity:
                return "{}{};".format(util.AMP_SUBSTITUTE, entity)
            else:
                return "%s#%d;" % (util.AMP_SUBSTITUTE, code)

        letters = [codepoint2name(ord(letter)) for letter in email]
        el.text = util.AtomicString(''.join(letters))

        mailto = "mailto:" + email
        mailto = "".join([util.AMP_SUBSTITUTE + '#%d;' %
                          ord(letter) for letter in mailto])
        el.set('href', mailto)
        return el, m.start(0), m.end(0)
